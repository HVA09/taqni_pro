/* ═══════════════════════════════════════════════
   FIREBASE ANALYTICS — تتبع الزيارات والسلوك
   ═══════════════════════════════════════════════
   يعمل تلقائياً عند تفعيل Firebase. يتتبع:
   - مشاهدات الصفحات
   - نقرات الشراء (Affiliate clicks)
   - عمليات البحث
   - إضافات المفضلة
   ═══════════════════════════════════════════════ */

let fbAnalytics = null;
if (FIREBASE_ENABLED && typeof firebase !== 'undefined' && firebase.analytics) {
  try { fbAnalytics = firebase.analytics(); } catch(e) {}
}

/* ── تسجيل مشاهدة صفحة ── */
function trackPageView(pageName) {
  if (fbAnalytics) {
    fbAnalytics.logEvent('page_view', { page_title: pageName, page_location: location.href });
  }
  /* console fallback للتطوير */
  console.log('📊 page_view:', pageName);
}

/* ── تسجيل نقرة شراء (الأهم لتتبع الأفلييت) ── */
function trackPurchaseClick(productId, productName, price) {
  if (fbAnalytics) {
    fbAnalytics.logEvent('select_item', {
      item_id: productId,
      item_name: productName,
      price: price,
      currency: 'USD',
    });
  }
  console.log('📊 purchase_click:', productName);
  /* سجّل أيضاً في Firestore للتقارير */
  if (typeof dbTrackClick === 'function') dbTrackClick(productId);
}

/* ── تسجيل عملية بحث ── */
function trackSearch(query) {
  if (fbAnalytics) {
    fbAnalytics.logEvent('search', { search_term: query });
  }
  console.log('📊 search:', query);
}

/* ── تسجيل إضافة للمفضلة ── */
function trackWishlistAdd(productId, productName) {
  if (fbAnalytics) {
    fbAnalytics.logEvent('add_to_wishlist', { item_id: productId, item_name: productName });
  }
  console.log('📊 wishlist_add:', productName);
}

/* ── تسجيل اشتراك النشرة البريدية ── */
function trackNewsletterSignup(email) {
  if (fbAnalytics) {
    fbAnalytics.logEvent('newsletter_signup', { method: 'email' });
  }
  console.log('📊 newsletter_signup');
}

/* ── تسجيل قراءة مقال ── */
function trackArticleRead(slug, title) {
  if (fbAnalytics) {
    fbAnalytics.logEvent('article_read', { article_slug: slug, article_title: title });
  }
  console.log('📊 article_read:', title);
}

/* ════════════════════════════════════
   AUTO-TRACK — تتبع تلقائي عند تحميل الصفحة
   ════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  const path = location.pathname.split('/').pop() || 'index.html';
  trackPageView(path);
});
