# 🔥 دليل ربط Firebase بموقع تقني برو

هذا الدليل يشرح خطوة بخطوة كيف تفعّل Firebase لإضافة:
تسجيل دخول حقيقي، قاعدة بيانات حية، ورفع صور، وتتبع تحليلات دقيق.

---

## ⚠️ مهم: الموقع يعمل بدون Firebase

موقعك **يعمل بشكل كامل الآن** بدون Firebase — كل البيانات في
`js/app.js` ولوحة التحكم تولّد كوداً تنسخه يدوياً. Firebase **اختياري**
لمن يريد قاعدة بيانات حية بدل التعديل اليدوي.

---

## الخطوة 1: إنشاء مشروع Firebase

1. افتح **console.firebase.google.com**
2. اضغط **Add project** (إضافة مشروع)
3. اكتب اسماً مثل `taqni-pro`
4. عطّل Google Analytics أو فعّله (اختياري)
5. اضغط **Create project**

---

## الخطوة 2: إضافة تطبيق ويب

1. في صفحة المشروع، اضغط أيقونة **</>** (Web)
2. سمّ التطبيق `taqni-pro-web`
3. اضغط **Register app**
4. ستظهر لك بيانات `firebaseConfig` — **انسخها**

---

## الخطوة 3: ضع البيانات في الموقع

1. افتح ملف `firebase/firebase-config.js`
2. استبدل القيم بالقيم التي نسختها:

```js
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "taqni-pro.firebaseapp.com",
  projectId: "taqni-pro",
  storageBucket: "taqni-pro.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

---

## الخطوة 4: فعّل Authentication

1. من القائمة الجانبية في Firebase، اضغط **Authentication**
2. اضغط **Get started**
3. اختر **Email/Password** وفعّله
4. احفظ

---

## الخطوة 5: فعّل Firestore Database

1. من القائمة الجانبية، اضغط **Firestore Database**
2. اضغط **Create database**
3. اختر **Start in test mode** (للتجربة، عدّل القواعد لاحقاً)
4. اختر أقرب موقع خادم لك
5. اضغط **Enable**

---

## الخطوة 6: أضف سكريبتات Firebase للموقع

في كل صفحة HTML تريد تفعيل Firebase فيها، أضف **قبل** إغلاق `</body>`:

```html
<!-- Firebase SDK -->
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-analytics-compat.js"></script>

<!-- ملفات Firebase الخاصة بالموقع -->
<script src="firebase/firebase-config.js"></script>
<script src="firebase/auth.js"></script>
<script src="firebase/database.js"></script>
<script src="firebase/analytics.js"></script>
```

> ⚠️ ضع هذه الأسطر **بعد** `js/app.js` في كل صفحة.

---

## الخطوة 7: أنشئ أول حساب أدمن

1. من Firebase Console، اذهب لـ **Authentication** → **Users**
2. اضغط **Add user**
3. أدخل بريدك وكلمة مرور
4. بعد الإنشاء، اذهب لـ **Firestore Database**
5. أنشئ مجموعة (collection) اسمها `users`
6. أنشئ مستند (document) بنفس الـ **UID** الخاص بالمستخدم الذي أنشأته
7. أضف حقل: `role` = `admin`

---

## الخطوة 8: تحديث صفحة الدخول

في `admin/login.html` استبدل دالة `doLogin()` لتستخدم:

```js
async function doLogin() {
  const email = document.getElementById('username').value;
  const pass  = document.getElementById('password').value;
  const result = await fbLogin(email, pass);
  if (result.success) {
    const isAdmin = await fbIsAdmin(result.user.uid);
    if (isAdmin) {
      window.location.href = 'dashboard.html';
    } else {
      alert('هذا الحساب ليس لديه صلاحيات إدارة');
    }
  } else {
    alert(result.error);
  }
}
```

---

## قواعد أمان Firestore (مهم جداً)

بعد الانتهاء من التجربة، عدّل قواعد الأمان من **test mode** إلى:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /products/{productId} {
      allow read: if true;
      allow write: if request.auth != null &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

---

## ملخص الفوائد بعد التفعيل

| الميزة | بدون Firebase | مع Firebase |
|---|---|---|
| تسجيل دخول | كلمة مرور ثابتة | حسابات حقيقية متعددة |
| إضافة منتج | نسخ كود يدوياً | حفظ مباشر في قاعدة بيانات |
| المفضلة | محلية بالمتصفح فقط | متزامنة عبر كل أجهزتك |
| التحليلات | تقديرية | دقيقة وحقيقية |
| رفع صور | غير متاح | متاح عبر Firebase Storage |

---

**جاهز؟** اتبع الخطوات بالترتيب وموقعك سيصبح متجراً حقيقياً متكاملاً 🚀
