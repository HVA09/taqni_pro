/* ═══════════════════════════════════════════════
   TAQNI PRO v2 — Data Store
   أضف منتجاتك ومقالاتك هنا بسهولة
   ═══════════════════════════════════════════════ */

const SITE = {
  name:     'تقني برو',
  slogan:   'برو',
  icon:     '⚡',
  url:      'https://hva09.github.io/taqni_pro',
  currency: '$',
  affBase:  'https://rzekl.com/g/1e8d1144949e80b8d7ee16525dc3e8/?ulp=',
  desc:     'أفضل منتجات التقنية بأسعار مضمونة',
  year:     '2026',
};

/* ── Helper: Build affiliate link ── */
const affLink = url => SITE.affBase + encodeURIComponent(url);

/* ════════════════════════════════════
   CATEGORIES
   ════════════════════════════════════ */
const CATS = {
  laptops:     { label:'لابتوبات',   icon:'💻', color:'#2563EB' },
  phones:      { label:'هواتف',      icon:'📱', color:'#10B981' },
  audio:       { label:'سماعات',     icon:'🎧', color:'#7C3AED' },
  cameras:     { label:'كاميرات',    icon:'📷', color:'#F59E0B' },
  drones:      { label:'درونات',     icon:'🚁', color:'#06B6D4' },
  smarthome:   { label:'منزل ذكي',   icon:'🏠', color:'#EF4444' },
  watches:     { label:'ساعات',      icon:'⌚', color:'#EC4899' },
  gaming:      { label:'جيمنج',      icon:'🎮', color:'#8B5CF6' },
  accessories: { label:'إكسسوارات',  icon:'🔌', color:'#F97316' },
};

/* ════════════════════════════════════
   PRODUCTS
   ════════════════════════════════════ */
const PRODUCTS = [
  {
    id:'macbook-air-m3', name:'MacBook Air M3', brand:'Apple', category:'laptops',
    price:1099, oldPrice:1299, rating:4.9, reviewCount:4821,
    badge:'الأكثر مبيعاً', badgeType:'hot', emoji:'💻', bg:'bg-blue',
    shortDesc:'أقوى لابتوب بحجمه بمعالج M3 وبطارية 18 ساعة',
    specs:[{n:'المعالج',v:'Apple M3 8-core'},{n:'الذاكرة',v:'8GB'},{n:'التخزين',v:'256GB SSD'},{n:'الشاشة',v:'13.6" Retina'},{n:'البطارية',v:'18 ساعة'}],
    pros:['أداء M3 استثنائي','بطارية 18 ساعة','وزن 1.24 كغ','شاشة Retina'],
    cons:['منافذ USB-C فقط','RAM غير قابلة للترقية'],
    url:'https://www.aliexpress.com/item/1005006489688179.html',
    reviews:[
      {name:'أحمد الشمري',rating:5,date:'يونيو 2026',text:'أداء لا يصدق! البطارية تدوم اليوم كله.'},
      {name:'سارة المطيري',rating:5,date:'مايو 2026',text:'أخف وأسرع لابتوب استخدمته في حياتي.'},
      {name:'محمد العتيبي',rating:4,date:'أبريل 2026',text:'ممتاز لكن أتمنى منافذ أكثر.'},
    ],
    metaTitle:'MacBook Air M3 أفضل سعر 2026',
    metaDesc:'اشترِ MacBook Air M3 بأفضل سعر. معالج M3، بطارية 18 ساعة.',
    featured:true,
  },
  {
    id:'iphone-17-pro', name:'iPhone 17 Pro', brand:'Apple', category:'phones',
    price:949, oldPrice:1199, rating:4.9, reviewCount:12043,
    badge:'🔥 جديد', badgeType:'hot', emoji:'📱', bg:'bg-blue',
    shortDesc:'أقوى iPhone بكاميرا 200MP ومعالج A19 Pro',
    specs:[{n:'المعالج',v:'A19 Pro'},{n:'الشاشة',v:'6.3" OLED 120Hz'},{n:'الكاميرا',v:'200MP'},{n:'التخزين',v:'256GB'},{n:'البطارية',v:'يوم كامل'}],
    pros:['معالج A19 الأقوى','كاميرا 200MP','هيكل Titanium','iOS محدّث'],
    cons:['سعر مرتفع','شاحن مباع منفصلاً'],
    url:'https://www.aliexpress.com/item/1005008653785482.html',
    reviews:[
      {name:'ريم الحربي',rating:5,date:'يونيو 2026',text:'أفضل هاتف! الكاميرا رائعة والأداء لا يصدق.'},
      {name:'خالد المنصور',rating:5,date:'مايو 2026',text:'يستحق كل ريال! A19 يجعله الأسرع في السوق.'},
    ],
    metaTitle:'iPhone 17 Pro أفضل سعر 2026',
    metaDesc:'اشترِ iPhone 17 Pro بأفضل سعر. كاميرا 200MP ومعالج A19 Pro.',
    featured:true,
  },
  {
    id:'sony-wh1000xm5', name:'Sony WH-1000XM5', brand:'Sony', category:'audio',
    price:280, oldPrice:399, rating:4.9, reviewCount:28432,
    badge:'الأفضل عالمياً', badgeType:'top', emoji:'🎧', bg:'bg-purple',
    shortDesc:'أفضل سماعة ANC في العالم بصوت Hi-Res',
    specs:[{n:'النوع',v:'Over-ear'},{n:'ANC',v:'الأقوى في السوق'},{n:'البطارية',v:'30 ساعة'},{n:'الاتصال',v:'BT 5.3'},{n:'الصوت',v:'Hi-Res + LDAC'}],
    pros:['أفضل ANC موجود','صوت Hi-Res','30 ساعة بطارية','مريح للارتداء'],
    cons:['لا مقاومة للماء'],
    url:'https://www.aliexpress.com/item/1005005164350330.html',
    reviews:[
      {name:'ياسر الحسيني',rating:5,date:'يونيو 2026',text:'ANC يلغي كل الضجيج. أفضل سماعة على الإطلاق!'},
      {name:'منى العيسى',rating:5,date:'مايو 2026',text:'صوت احترافي ومريح جداً.'},
      {name:'عمر الشراري',rating:5,date:'أبريل 2026',text:'لن تندم على شرائها أبداً.'},
    ],
    metaTitle:'Sony WH-1000XM5 أفضل سعر 2026',
    metaDesc:'اشترِ Sony WH-1000XM5 بأفضل سعر. أفضل سماعة ANC بصوت Hi-Res.',
    featured:true,
  },
  {
    id:'samsung-s25-ultra', name:'Samsung S25 Ultra', brand:'Samsung', category:'phones',
    price:1199, oldPrice:1399, rating:4.8, reviewCount:8765,
    badge:'أندرويد #1', badgeType:'pro', emoji:'📱', bg:'bg-slate',
    shortDesc:'أقوى أندرويد بقلم S Pen وكاميرا 200MP',
    specs:[{n:'المعالج',v:'Snapdragon 8 Elite'},{n:'الشاشة',v:'6.9" AMOLED 120Hz'},{n:'الكاميرا',v:'200MP'},{n:'البطارية',v:'5000mAh'},{n:'الميزة',v:'S Pen مدمج'}],
    pros:['S Pen مدمج','كاميرا zoom 10x','شاشة ضخمة','بطارية 5000mAh'],
    cons:['ضخم وثقيل','سعر مرتفع'],
    url:'https://www.aliexpress.com/item/1005008653785482.html',
    reviews:[{name:'فهد الدوسري',rating:5,date:'يونيو 2026',text:'أفضل هاتف أندرويد بلا منازع!'}],
    metaTitle:'Samsung S25 Ultra أفضل سعر',
    metaDesc:'Samsung S25 Ultra بـ S Pen وكاميرا 200MP.',
    featured:false,
  },
  {
    id:'dji-mini-4-pro', name:'DJI Mini 4 Pro', brand:'DJI', category:'drones',
    price:759, oldPrice:959, rating:4.8, reviewCount:7832,
    badge:'الأخف عالمياً', badgeType:'new', emoji:'🚁', bg:'bg-cyan',
    shortDesc:'درون 4K 249 جرام بتجنب عقبات 360 درجة',
    specs:[{n:'الكاميرا',v:'4K/60fps HDR'},{n:'الوزن',v:'249 جرام'},{n:'الطيران',v:'34 دقيقة'},{n:'المدى',v:'20 كم'},{n:'التتبع',v:'ActiveTrack 360°'}],
    pros:['249 جرام بدون ترخيص','4K HDR مذهل','تتبع ذكي 360'],
    cons:['لا zoom بصري','مستلزمات مكلفة'],
    url:'https://www.aliexpress.com/item/1005004843861621.html',
    reviews:[{name:'بدر الشامي',rating:5,date:'يونيو 2026',text:'صور هوائية احترافية بجسم خفيف رائع!'}],
    metaTitle:'DJI Mini 4 Pro أفضل سعر 2026',
    metaDesc:'DJI Mini 4 Pro درون 4K HDR 249 جرام.',
    featured:false,
  },
  {
    id:'ps5-pro', name:'PlayStation 5 Pro', brand:'Sony', category:'gaming',
    price:699, oldPrice:799, rating:4.9, reviewCount:32109,
    badge:'الأكثر مبيعاً', badgeType:'hot', emoji:'🎮', bg:'bg-blue',
    shortDesc:'PS5 Pro بـ 4K مذهل وPlayStation Spectral SR',
    specs:[{n:'المعالج',v:'AMD Zen 2 Enhanced'},{n:'GPU',v:'RDNA 3 Enhanced'},{n:'التخزين',v:'2TB SSD'},{n:'الرسومات',v:'4K + Ray Tracing'}],
    pros:['4K/60fps مذهل','مكتبة ألعاب ضخمة','DualSense رائع'],
    cons:['حجم ضخم','يحتاج تلفزيون 4K'],
    url:'https://www.aliexpress.com/item/1005004843861621.html',
    reviews:[{name:'سعد البدراني',rating:5,date:'يونيو 2026',text:'يحوّل الجيمنج لتجربة سينمائية!'}],
    metaTitle:'PS5 Pro أفضل سعر 2026',
    metaDesc:'PlayStation 5 Pro بـ 4K وPlayStation SR.',
    featured:false,
  },
  {
    id:'apple-watch-s10', name:'Apple Watch Series 10', brand:'Apple', category:'watches',
    price:399, oldPrice:499, rating:4.8, reviewCount:19043,
    badge:'🔥 جديد', badgeType:'hot', emoji:'⌚', bg:'bg-blue',
    shortDesc:'ساعة Apple الأرق والأخف بمستشعرات صحة متطورة',
    specs:[{n:'الشاشة',v:'46mm OLED'},{n:'السُمك',v:'9.7mm الأرق'},{n:'المستشعرات',v:'ECG + SpO2'},{n:'WatchOS',v:'WatchOS 11'}],
    pros:['الأرق في تاريخ Apple Watch','مستشعرات صحة شاملة','شحن سريع'],
    cons:['يصلح لـ iPhone فقط','بطارية يومين'],
    url:'https://www.aliexpress.com/item/1005004843861621.html',
    reviews:[{name:'زينب المزروع',rating:5,date:'يونيو 2026',text:'أجمل ساعة ذكية! مستشعرات دقيقة جداً.'}],
    metaTitle:'Apple Watch Series 10 أفضل سعر',
    metaDesc:'Apple Watch S10 الأرق والأخف بمستشعرات متقدمة.',
    featured:false,
  },
  {
    id:'airpods-pro-2', name:'AirPods Pro 2', brand:'Apple', category:'audio',
    price:199, oldPrice:249, rating:4.8, reviewCount:45231,
    badge:'آبل', badgeType:'hot', emoji:'🎧', bg:'bg-blue',
    shortDesc:'أفضل سماعات Apple بـ ANC وصوت Spatial ثلاثي',
    specs:[{n:'النوع',v:'In-ear'},{n:'ANC',v:'H2 chip'},{n:'البطارية',v:'6h + 30 علبة'},{n:'مقاومة الماء',v:'IP54'}],
    pros:['ANC رائع','Spatial Audio ثلاثي','تكامل Apple مثالي','IP54'],
    cons:['لمستخدمي Apple فقط','بطارية 6 ساعات'],
    url:'https://www.aliexpress.com/item/1005005164350330.html',
    reviews:[{name:'أميرة الجهني',rating:5,date:'يونيو 2026',text:'مثالية مع iPhone! ANC ممتاز.'}],
    metaTitle:'AirPods Pro 2 أفضل سعر',
    metaDesc:'AirPods Pro 2 بـ ANC وSpatial Audio.',
    featured:false,
  },
  {
    id:'anker-powercore', name:'Anker PowerCore 26800', brand:'Anker', category:'accessories',
    price:79, oldPrice:99, rating:4.7, reviewCount:15432,
    badge:'ضروري', badgeType:'sale', emoji:'🔋', bg:'bg-cyan',
    shortDesc:'بطارية محمولة ضخمة تشحن لابتوبك بـ 65W',
    specs:[{n:'السعة',v:'26800mAh'},{n:'الشحن',v:'65W PD'},{n:'المنافذ',v:'USB-C×2 + USB-A'},{n:'الوزن',v:'430 جرام'}],
    pros:['يشحن اللابتوب','شحن سريع 65W','سعة ضخمة','بناء متين'],
    cons:['شحنها 3-4 ساعات'],
    url:'https://www.aliexpress.com/item/1005004843861621.html',
    reviews:[{name:'تركي السبيعي',rating:5,date:'يونيو 2026',text:'يشحن لابتوبي وهاتفي في نفس الوقت!'}],
    metaTitle:'Anker PowerCore 26800 أفضل سعر',
    metaDesc:'Anker PowerCore 26800mAh بشحن سريع 65W.',
    featured:false,
  },
  {
    id:'dell-xps-15', name:'Dell XPS 15 2026', brand:'Dell', category:'laptops',
    price:1449, oldPrice:1699, rating:4.7, reviewCount:2341,
    badge:'برو', badgeType:'pro', emoji:'💻', bg:'bg-green',
    shortDesc:'لابتوب الاحتراف بشاشة OLED 3.5K ومعالج Ultra 9',
    specs:[{n:'المعالج',v:'Intel Core Ultra 9'},{n:'الذاكرة',v:'32GB DDR5'},{n:'التخزين',v:'1TB NVMe'},{n:'الشاشة',v:'15.6" OLED 3.5K'},{n:'GPU',v:'RTX 4070'}],
    pros:['شاشة OLED مذهلة','أداء رهيب','بناء premium'],
    cons:['وزن 2.05 كغ','بطارية 6 ساعات'],
    url:'https://www.aliexpress.com/item/1005004843861621.html',
    reviews:[{name:'عبدالله الرشيد',rating:5,date:'يونيو 2026',text:'شاشة OLED تجعل كل الصور حية!'}],
    metaTitle:'Dell XPS 15 2026 أفضل سعر',
    metaDesc:'Dell XPS 15 بشاشة OLED للمحترفين.',
    featured:false,
  },
  {
    id:'xiaomi-14-ultra', name:'Xiaomi 14 Ultra', brand:'Xiaomi', category:'phones',
    price:699, oldPrice:799, rating:4.7, reviewCount:5432,
    badge:'قيمة', badgeType:'sale', emoji:'📱', bg:'bg-green',
    shortDesc:'هاتف Leica بكاميرا احترافية وشحن 90W',
    specs:[{n:'المعالج',v:'Snapdragon 8 Gen 3'},{n:'الشاشة',v:'6.73" AMOLED 120Hz'},{n:'الكاميرا',v:'Leica 50MP'},{n:'الشحن',v:'90W سريع'}],
    pros:['كاميرا Leica احترافية','شحن 90W','سعر ممتاز','تصميم راقٍ'],
    cons:['خدمة ما بعد البيع محدودة'],
    url:'https://www.aliexpress.com/item/1005008653785482.html',
    reviews:[{name:'سالم البلوشي',rating:5,date:'مايو 2026',text:'كاميرا Leica بهذا السعر؟ لا يصدق!'}],
    metaTitle:'Xiaomi 14 Ultra كاميرا Leica أفضل سعر',
    metaDesc:'Xiaomi 14 Ultra بكاميرا Leica وشحن 90W.',
    featured:false,
  },
  {
    id:'gopro-hero13', name:'GoPro HERO13 Black', brand:'GoPro', category:'cameras',
    price:399, oldPrice:449, rating:4.7, reviewCount:9203,
    badge:'أكشن', badgeType:'sale', emoji:'📷', bg:'bg-amber',
    shortDesc:'كاميرا أكشن 5.3K بـ HyperSmooth ومقاومة 10 أمتار',
    specs:[{n:'الدقة',v:'5.3K 60fps'},{n:'التثبيت',v:'HyperSmooth 6.0'},{n:'الماء',v:'10 أمتار'},{n:'الشاشة',v:'أمامية + خلفية'}],
    pros:['تثبيت HyperSmooth رائع','مقاومة ماء ممتازة','خفيفة وصغيرة'],
    cons:['بطارية محدودة في 5.3K'],
    url:'https://www.aliexpress.com/item/1005004843861621.html',
    reviews:[{name:'بدر العلوي',rating:5,date:'مايو 2026',text:'لا مثيل لها في رياضات الماء!'}],
    metaTitle:'GoPro HERO13 Black أفضل سعر',
    metaDesc:'GoPro HERO13 Black كاميرا أكشن 5.3K.',
    featured:false,
  },
];

/* ════════════════════════════════════
   ARTICLES
   ════════════════════════════════════ */
const ARTICLES = [
  {
    slug:'best-headphones-2026',
    title:'أفضل 10 سماعات لاسلكية في 2026 — دليل شامل',
    excerpt:'دليلك الكامل لاختيار السماعة المثالية مع مقارنة تفصيلية لأفضل 10 موديلات.',
    category:'سماعات', catColor:'#7C3AED',
    date:'2026-06-01', dateAr:'1 يونيو 2026', readTime:8,
    emoji:'🎧', bg:'bg-purple',
    content:`
<h2>ما يجعل السماعة رائعة في 2026؟</h2>
<p>مع تطور Bluetooth 5.3 وخوارزميات ANC المعززة بالذكاء الاصطناعي، أصبحت السماعات اللاسلكية أفضل من أي وقت مضى.</p>
<div class="art-highlight">💡 حدّد استخدامك أولاً: عمل؟ موسيقى؟ رياضة؟ هذا يحدد الخيار المثالي.</div>
<h2>أهم معايير الاختيار</h2>
<ul>
  <li><strong>جودة الصوت:</strong> Hi-Res Audio وترددات واسعة</li>
  <li><strong>ANC:</strong> ضروري للعمل في الأماكن المزدحمة</li>
  <li><strong>البطارية:</strong> 20 ساعة+ للاستخدام اليومي</li>
  <li><strong>الراحة:</strong> مهم للارتداء ساعات طويلة</li>
</ul>
<h2>أفضل 3 في 2026</h2>
<h3>1. Sony WH-1000XM5 — الأفضل على الإطلاق</h3>
<p>ANC الأقوى في السوق وصوت Hi-Res. البطارية 30 ساعة وMulti-point للاتصال بجهازين.</p>
<h3>2. Apple AirPods Pro 2 — لمنظومة Apple</h3>
<p>Spatial Audio ثلاثي الأبعاد وANC ممتاز مع IP54.</p>
<h3>3. Jabra Evolve2 85 — للمحترفين</h3>
<p>ميكروفون استثنائي و37 ساعة بطارية. مثالي للاجتماعات عن بعد.</p>`,
    relatedProductIds:['sony-wh1000xm5','airpods-pro-2'],
    metaTitle:'أفضل سماعات لاسلكية 2026 | تقني برو',
    metaDesc:'مقارنة أفضل 10 سماعات 2026: Sony, Apple, Jabra.',
  },
  {
    slug:'laptop-guide-2026',
    title:'دليل شراء اللابتوب 2026 — كل ما تحتاج معرفته',
    excerpt:'قبل شراء لابتوبك القادم، اقرأ هذا الدليل لتوفير أموالك واتخاذ القرار الأمثل.',
    category:'لابتوبات', catColor:'#10B981',
    date:'2026-05-01', dateAr:'1 مايو 2026', readTime:10,
    emoji:'💻', bg:'bg-green',
    content:`
<h2>أول خطوة: ما استخدامك؟</h2>
<ul>
  <li><strong>طالب / مكتبي:</strong> 8GB RAM كافٍ</li>
  <li><strong>تصميم / محتوى:</strong> MacBook Air M3</li>
  <li><strong>جيمنج:</strong> ASUS ROG بكارت NVIDIA</li>
</ul>
<h2>المواصفات الأهم</h2>
<h3>المعالج</h3>
<p>Apple M3 يتصدر الأداء لكل الاستخدامات. لـ Windows: Intel Core Ultra 9.</p>
<h3>الذاكرة</h3>
<p>8GB الحد الأدنى. لأي عمل جاد: 16GB.</p>
<div class="art-highlight">💡 MacBook Air M3 يبقى الأفضل قيمة في 2026</div>`,
    relatedProductIds:['macbook-air-m3','dell-xps-15'],
    metaTitle:'دليل شراء لابتوب 2026 | تقني برو',
    metaDesc:'كيف تختار اللابتوب المناسب في 2026.',
  },
  {
    slug:'save-money-tech',
    title:'10 طرق ذكية لتوفير المال عند شراء الإلكترونيات',
    excerpt:'أسرار لتوفير مئات الدولارات عند شراء أجهزتك التقنية.',
    category:'نصائح', catColor:'#F59E0B',
    date:'2026-04-15', dateAr:'15 أبريل 2026', readTime:6,
    emoji:'💰', bg:'bg-amber',
    content:`
<h2>1. انتظر مواسم الخصومات</h2>
<p>Black Friday وAmazon Prime Day يقدمان خصومات تصل لـ 40%.</p>
<h2>2. قارن على عدة متاجر</h2>
<p>نفس المنتج قد يختلف سعره بـ $50-200 بين المتاجر.</p>
<h2>3. فكّر في الجيل السابق</h2>
<p>iPhone 16 Pro بعد صدور iPhone 17 Pro بنفس الأداء تقريباً بسعر أقل 30%.</p>
<div class="art-highlight">💡 موقعنا يبحث لك عن أفضل سعر تلقائياً!</div>`,
    relatedProductIds:['macbook-air-m3','iphone-17-pro'],
    metaTitle:'10 طرق لتوفير المال على الإلكترونيات | تقني برو',
    metaDesc:'نصائح ذكية لتوفير المال عند شراء الإلكترونيات.',
  },
];

/* ════════════════════════════════════
   HELPERS
   ════════════════════════════════════ */
const disc   = p => Math.round(((p.oldPrice - p.price) / p.oldPrice) * 100);
const stars  = r => '★'.repeat(Math.floor(r)) + '☆'.repeat(5 - Math.ceil(r));
const bdgCls = t => ({ hot:'b-hot', new:'b-new', sale:'b-sale', top:'b-top', pro:'b-pro' }[t] || 'b-hot');
const curr   = v => SITE.currency + v;

/* ════════════════════════════════════
   CLICK & VIEW TRACKING
   يعمل محلياً دائماً، ويتصل بـ Firebase تلقائياً إن وُجد
   ════════════════════════════════════ */
function trackClick(productId) {
  /* Local fallback (يعمل دائماً) */
  try {
    const clicks = JSON.parse(localStorage.getItem('tp_clicks') || '{}');
    clicks[productId] = (clicks[productId] || 0) + 1;
    localStorage.setItem('tp_clicks', JSON.stringify(clicks));
  } catch(e) {}

  /* Firebase (إن كان مفعّلاً) */
  const p = PRODUCTS.find(x => x.id === productId);
  if (typeof trackPurchaseClick === 'function' && p) {
    trackPurchaseClick(productId, p.name, p.price);
  } else if (typeof dbTrackClick === 'function') {
    dbTrackClick(productId);
  }
}

function trackView(productId) {
  try {
    const views = JSON.parse(localStorage.getItem('tp_views') || '{}');
    views[productId] = (views[productId] || 0) + 1;
    localStorage.setItem('tp_views', JSON.stringify(views));
  } catch(e) {}

  if (typeof dbTrackView === 'function') dbTrackView(productId);
}

/* ════════════════════════════════════
   WISHLIST
   ════════════════════════════════════ */
let wishlist = [];
try { wishlist = JSON.parse(localStorage.getItem('tp_wl') || '[]'); } catch(e) {}

function toggleWL(e, id) {
  e.stopPropagation();
  wishlist = wishlist.includes(id) ? wishlist.filter(x => x !== id) : [...wishlist, id];
  try { localStorage.setItem('tp_wl', JSON.stringify(wishlist)); } catch(ex) {}
  updateWLIcons();
  updateWLBadge();
}

function updateWLIcons() {
  document.querySelectorAll('.p-heart').forEach(h => {
    const id = h.closest('[data-id]')?.dataset.id;
    if (!id) return;
    const l = wishlist.includes(id);
    h.textContent = l ? '♥' : '♡';
    h.classList.toggle('loved', l);
  });
}

function updateWLBadge() {
  const b = document.getElementById('wl-badge');
  if (b) { b.textContent = wishlist.length; b.classList.toggle('show', wishlist.length > 0); }
}

/* ════════════════════════════════════
   PRODUCT CARD TEMPLATE
   ════════════════════════════════════ */
function tplCard(p) {
  const loved = wishlist.includes(p.id);
  return `
<a class="p-card" data-id="${p.id}" href="product.html?id=${p.id}" itemscope itemtype="https://schema.org/Product">
  <meta itemprop="name" content="${p.name}"/>
  <div class="p-img ${p.bg}">
    <span class="p-badge ${bdgCls(p.badgeType)}">${p.badge}</span>
    <div class="p-heart${loved?' loved':''}" onclick="toggleWL(event,'${p.id}')">${loved?'♥':'♡'}</div>
    <span itemprop="image">${p.emoji}</span>
  </div>
  <div class="p-body">
    <div class="p-brand">${p.brand}</div>
    <div class="p-name" itemprop="name">${p.name}</div>
    <div class="p-desc">${p.shortDesc}</div>
    <div class="p-stars">${stars(p.rating)}</div>
    <div class="p-revs">(${p.reviewCount.toLocaleString()} تقييم)</div>
    <div class="p-pricing" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
      <meta itemprop="priceCurrency" content="USD"/>
      <link itemprop="availability" href="https://schema.org/InStock"/>
      <span class="p-price" itemprop="price" content="${p.price}">${curr(p.price)}</span>
      <span class="p-old">${curr(p.oldPrice)}</span>
      <span class="p-disc">-${disc(p)}%</span>
    </div>
    <button class="p-btn" onclick="event.preventDefault();event.stopPropagation();trackClick('${p.id}');window.open('${affLink(p.url)}','_blank')">
      🛒 اشتري الآن
    </button>
  </div>
</a>`;
}

/* Deal card */
function tplDeal(p) {
  return `
<div class="deal-c" onclick="trackClick('${p.id}');window.open('${affLink(p.url)}','_blank')">
  <div class="deal-ribbon">-${disc(p)}%</div>
  <span class="deal-emoji">${p.emoji}</span>
  <div class="deal-name">${p.name}</div>
  <div class="deal-price">${curr(p.price)}</div>
  <div class="deal-old">${curr(p.oldPrice)}</div>
  <button class="deal-btn">🛒 اشتري</button>
</div>`;
}

/* Article card */
function tplArtCard(a) {
  return `
<a class="art-card" href="blog.html?article=${a.slug}">
  <div class="art-img ${a.bg}">${a.emoji}</div>
  <div class="art-body">
    <span class="art-cat" style="background:${a.catColor}18;color:${a.catColor}">${a.category}</span>
    <div class="art-title">${a.title}</div>
    <div class="art-excerpt">${a.excerpt}</div>
    <div class="art-meta">
      <span>📅 ${a.dateAr}</span>
      <span>⏱️ ${a.readTime} دقائق</span>
    </div>
  </div>
</a>`;
}

/* Section header */
function tplSecTop(eye, title, moreHref = '') {
  return `
<div class="sec-top">
  <div><div class="sec-eye">${eye}</div><div class="sec-h">${title}</div></div>
  ${moreHref ? `<a class="sec-more" href="${moreHref}">عرض الكل ←</a>` : ''}
</div>`;
}

/* ════════════════════════════════════
   SHARED UI INIT
   ════════════════════════════════════ */
function initShared() {
  /* Countdown */
  (function(){
    function upd(){
      var el=document.getElementById('cdH');if(!el)return;
      var n=new Date(),e=new Date(n);e.setHours(23,59,59,0);var d=e-n;
      var hEl=document.getElementById('cdH');if(hEl)hEl.textContent=String(Math.floor(d/3.6e6)).padStart(2,'0');
      var mEl=document.getElementById('cdM');if(mEl)mEl.textContent=String(Math.floor((d%3.6e6)/6e4)).padStart(2,'0');
      var sEl=document.getElementById('cdS');if(sEl)sEl.textContent=String(Math.floor((d%6e4)/1e3)).padStart(2,'0');
    }
    upd();setInterval(upd,1000);
  })();

  /* Back to top */
  window.addEventListener('scroll',()=>{
    const b=document.getElementById('btt');
    if(b)b.classList.toggle('show',scrollY>400);
  });

  /* FAQ */
  document.addEventListener('click',e=>{
    const item=e.target.closest('.faq-item');
    if(item)item.classList.toggle('open');
  });

  /* Newsletter */
  document.querySelectorAll('.nl-form').forEach(form=>{
    form.addEventListener('submit',e=>{
      e.preventDefault();
      const inp=form.querySelector('input[type="email"]');
      if(inp&&inp.value.includes('@')){
        form.innerHTML='<p style="color:#10b981;font-weight:800;font-size:16px">✅ شكراً! سيصلك ملخص أفضل العروض.</p>';
      }
    });
  });

  /* Mobile drawer */
  const ham=document.getElementById('ham');
  const overlay=document.getElementById('d-overlay');
  const drawer=document.getElementById('drawer');
  if(ham) ham.addEventListener('click',()=>{drawer.classList.add('open');overlay.classList.add('open');document.body.style.overflow='hidden';});
  if(overlay) overlay.addEventListener('click',()=>{drawer.classList.remove('open');overlay.classList.remove('open');document.body.style.overflow='';});
  document.querySelectorAll('.drawer-close').forEach(b=>b.addEventListener('click',()=>{drawer.classList.remove('open');overlay.classList.remove('open');document.body.style.overflow='';}));

  /* Active nav link */
  const page=location.pathname.split('/').pop()||'index.html';
  document.querySelectorAll('.nav-a').forEach(a=>{
    if(a.getAttribute('href')===page)a.classList.add('active');
  });

  /* Search */
  const sinp=document.getElementById('nav-q');
  if(sinp){
    sinp.addEventListener('keydown',e=>{
      if(e.key==='Enter'){
        const q=sinp.value.trim();
        if(q)location.href=`products.html?q=${encodeURIComponent(q)}`;
      }
    });
    document.getElementById('nav-search-btn')?.addEventListener('click',()=>{
      const q=sinp.value.trim();
      if(q)location.href=`products.html?q=${encodeURIComponent(q)}`;
    });
  }

  /* Exit popup */
  let popupShown=false;
  document.addEventListener('mouseleave',e=>{
    if(e.clientY<0&&!popupShown&&!sessionStorage.getItem('popup_shown')){
      popupShown=true;sessionStorage.setItem('popup_shown','1');
      document.getElementById('exit-popup')?.classList.add('show');
    }
  });

  updateWLBadge();
}

/* ════════════════════════════════════
   SEO META UPDATER
   ════════════════════════════════════ */
function setMeta(title, desc) {
  document.title = title + ' | ' + SITE.name;
  document.querySelector('meta[name="description"]')?.setAttribute('content', desc);
  document.querySelector('meta[property="og:title"]')?.setAttribute('content', title);
  document.querySelector('meta[property="og:description"]')?.setAttribute('content', desc);
}

/* ════════════════════════════════════
   SHARED HEADER/FOOTER INJECT
   ════════════════════════════════════ */
function injectHeader() {
  const el = document.getElementById('header-placeholder');
  if (!el) return;
  const page = location.pathname.split('/').pop() || 'index.html';
  const nl = (id, href, label) => `<a class="nav-a${page===href?' active':''}" href="${href}">${label}</a>`;
  el.innerHTML = `
<div class="topbar">
  <span class="topbar-pill">⚡ عرض</span>
  <span>شحن مجاني على الطلبات فوق <strong style="color:var(--gold)">$50</strong> — عرض اليوم فقط!</span>
  <span class="topbar-pill">🚀</span>
</div>
<nav class="main-nav" role="navigation">
  <div class="nav-wrap">
    <a class="logo" href="index.html"><div class="logo-icon">${SITE.icon}</div>${SITE.name} <em>${SITE.slogan}</em></a>
    <div class="nav-links">
      ${nl('nl-home','index.html','🏠 الرئيسية')}
      ${nl('nl-products','products.html','🛍️ المنتجات')}
      ${nl('nl-blog','blog.html','📝 المدونة')}
      ${nl('nl-contact','contact.html','📞 تواصل')}
    </div>
    <div class="nav-search">
      <input type="search" id="nav-q" placeholder="ابحث عن منتج..." autocomplete="off">
      <button class="nav-search-btn" id="nav-search-btn">🔍</button>
    </div>
    <div class="nav-end">
      <button class="icon-btn" onclick="location.href='products.html?wishlist=1'" title="المفضلة">
        ♡ <span class="badge" id="wl-badge">0</span>
      </button>
      <a class="nav-cta" href="products.html">🛍️ تسوّق</a>
      <button class="hamburger" id="ham"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>
<div class="cat-nav">
  <div class="cat-nav-inner">
    ${Object.entries(CATS).map(([k,c])=>`<a class="cat-nav-a" href="products.html?cat=${k}">${c.icon} ${c.label}</a>`).join('')}
  </div>
</div>
<div class="drawer-overlay" id="d-overlay"></div>
<div class="drawer" id="drawer">
  <div class="drawer-head">
    <div class="logo"><div class="logo-icon">${SITE.icon}</div>${SITE.name} <em>${SITE.slogan}</em></div>
    <button class="drawer-close">✕</button>
  </div>
  <div class="drawer-body">
    <a class="d-link" href="index.html"><span>🏠</span> الرئيسية</a>
    <a class="d-link" href="products.html"><span>🛍️</span> جميع المنتجات</a>
    <a class="d-link" href="blog.html"><span>📝</span> المدونة</a>
    <a class="d-link" href="contact.html"><span>📞</span> تواصل معنا</a>
    <div class="drawer-sec">الفئات</div>
    ${Object.entries(CATS).map(([k,c])=>`<a class="d-cat" href="products.html?cat=${k}">${c.icon} ${c.label}</a>`).join('')}
  </div>
</div>`;
}

function injectFooter() {
  const el = document.getElementById('footer-placeholder');
  if (!el) return;
  el.innerHTML = `
<div class="trust-bar">
  <div class="trust-inner">
    <div class="t-item"><div class="t-ico">🚚</div><div class="t-text"><strong>شحن سريع</strong><span>التوصيل لباب بيتك</span></div></div>
    <div class="t-item"><div class="t-ico">🛡️</div><div class="t-text"><strong>شراء آمن 100%</strong><span>متاجر عالمية موثوقة</span></div></div>
    <div class="t-item"><div class="t-ico">💰</div><div class="t-text"><strong>أقل سعر مضمون</strong><span>نبحث لك عن الأرخص</span></div></div>
    <div class="t-item"><div class="t-ico">⭐</div><div class="t-text"><strong>مراجعات حقيقية</strong><span>نختبر كل منتج</span></div></div>
    <div class="t-item"><div class="t-ico">↩️</div><div class="t-text"><strong>إرجاع سهل</strong><span>ضمان المتجر الأصلي</span></div></div>
  </div>
</div>
<footer>
  <div class="footer-main">
    <div>
      <a class="foot-logo" href="index.html"><div class="logo-icon">${SITE.icon}</div>${SITE.name} <em>${SITE.slogan}</em></a>
      <p class="foot-desc">${SITE.desc}. نختار لك الأفضل بأقل سعر مضمون.</p>
      <div class="foot-disc">🔗 <strong>إفصاح:</strong> يحتوي هذا الموقع روابط أفلييت. نحصل على عمولة عند شرائك عبرها بدون تكلفة إضافية.</div>
      <div class="foot-social">
        <div class="soc-i">𝕏</div><div class="soc-i">📘</div><div class="soc-i">📸</div><div class="soc-i">▶️</div>
      </div>
    </div>
    <div class="foot-col">
      <h4>الفئات</h4>
      <ul>${Object.entries(CATS).slice(0,5).map(([k,c])=>`<li><a href="products.html?cat=${k}">${c.icon} ${c.label}</a></li>`).join('')}</ul>
    </div>
    <div class="foot-col">
      <h4>الموقع</h4>
      <ul>
        <li><a href="index.html">🏠 الرئيسية</a></li>
        <li><a href="products.html">🛍️ المنتجات</a></li>
        <li><a href="blog.html">📝 المدونة</a></li>
        <li><a href="contact.html">📞 تواصل</a></li>
      </ul>
    </div>
    <div class="foot-col">
      <h4>قانوني</h4>
      <ul>
        <li><a href="privacy-policy.html">🔒 الخصوصية</a></li>
        <li><a href="terms.html">📋 الشروط</a></li>
        <li><a href="affiliate-disclosure.html">🔗 إفصاح</a></li>
        <li><a href="sitemap.xml">🗺️ خريطة الموقع</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <span>⚡ ${SITE.name} — جميع الحقوق محفوظة ${SITE.year}</span>
    <div style="display:flex;gap:12px">
      <a href="privacy-policy.html">سياسة الخصوصية</a>
      <a href="terms.html">الشروط</a>
    </div>
  </div>
</footer>
<nav class="bnav">
  <div class="bnav-inner">
    <a class="bnav-i" href="index.html"><div class="bnav-ico">🏠</div>الرئيسية</a>
    <a class="bnav-i" href="products.html"><div class="bnav-ico">🛍️</div>المنتجات</a>
    <a class="bnav-i" href="products.html"><div class="bnav-ico">🔍</div>بحث</a>
    <a class="bnav-i" href="blog.html"><div class="bnav-ico">📝</div>المدونة</a>
    <a class="bnav-i" href="products.html?wishlist=1"><div class="bnav-ico">♡</div>مفضلة</a>
  </div>
</nav>
<button id="btt" onclick="window.scrollTo({top:0,behavior:'smooth'})">↑</button>
<!-- Exit Popup -->
<div class="popup-overlay" id="exit-popup">
  <div class="popup-box">
    <button class="popup-close" onclick="document.getElementById('exit-popup').classList.remove('show')">✕</button>
    <div class="popup-emoji">🎁</div>
    <div class="popup-title">انتظر! لديك خصم حصري</div>
    <div class="popup-desc">اشترك الآن واحصل على كود خصم 10% على أول طلب</div>
    <div class="popup-code">TAQNI10</div>
    <button class="popup-btn" onclick="document.getElementById('exit-popup').classList.remove('show');document.getElementById('nl-section')?.scrollIntoView({behavior:'smooth'})">احصل على الخصم الآن</button>
  </div>
</div>`;
}
