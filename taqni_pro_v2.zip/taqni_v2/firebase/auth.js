/* ═══════════════════════════════════════════════
   FIREBASE AUTH — نظام تسجيل الدخول والمستخدمين
   ═══════════════════════════════════════════════
   هذا الملف يعمل تلقائياً فقط إذا كان Firebase مفعّلاً
   في firebase-config.js. إذا لم يكن مفعّلاً، يعمل
   النظام القديم (admin/login.html بكلمة مرور ثابتة).
   ═══════════════════════════════════════════════ */

/* ── تسجيل دخول بالبريد وكلمة المرور ── */
async function fbLogin(email, password) {
  if (!FIREBASE_ENABLED) {
    return { success:false, error:'Firebase غير مفعّل. أضف بياناتك في firebase-config.js' };
  }
  try {
    const result = await firebaseAuth.signInWithEmailAndPassword(email, password);
    return { success:true, user:result.user };
  } catch (e) {
    const messages = {
      'auth/user-not-found':      'البريد الإلكتروني غير مسجّل',
      'auth/wrong-password':      'كلمة المرور غير صحيحة',
      'auth/invalid-email':       'صيغة البريد الإلكتروني غير صحيحة',
      'auth/too-many-requests':   'محاولات كثيرة، حاول لاحقاً',
      'auth/user-disabled':       'هذا الحساب معطّل',
    };
    return { success:false, error: messages[e.code] || e.message };
  }
}

/* ── إنشاء حساب مستخدم جديد ── */
async function fbRegister(email, password, displayName) {
  if (!FIREBASE_ENABLED) {
    return { success:false, error:'Firebase غير مفعّل' };
  }
  try {
    const result = await firebaseAuth.createUserWithEmailAndPassword(email, password);
    if (displayName) await result.user.updateProfile({ displayName });

    /* إنشاء سجل المستخدم في قاعدة البيانات */
    await firebaseDB.collection('users').doc(result.user.uid).set({
      email: email,
      displayName: displayName || '',
      role: 'customer',          /* customer | admin */
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      wishlist: [],
    });

    return { success:true, user:result.user };
  } catch (e) {
    const messages = {
      'auth/email-already-in-use': 'هذا البريد مسجّل مسبقاً',
      'auth/weak-password':        'كلمة المرور ضعيفة جداً (6 أحرف على الأقل)',
      'auth/invalid-email':        'صيغة البريد الإلكتروني غير صحيحة',
    };
    return { success:false, error: messages[e.code] || e.message };
  }
}

/* ── تسجيل الخروج ── */
async function fbLogout() {
  if (!FIREBASE_ENABLED) return;
  await firebaseAuth.signOut();
}

/* ── مراقبة حالة تسجيل الدخول ── */
function fbOnAuthChange(callback) {
  if (!FIREBASE_ENABLED) { callback(null); return; }
  firebaseAuth.onAuthStateChanged(callback);
}

/* ── التحقق هل المستخدم الحالي أدمن ── */
async function fbIsAdmin(uid) {
  if (!FIREBASE_ENABLED || !uid) return false;
  try {
    const doc = await firebaseDB.collection('users').doc(uid).get();
    return doc.exists && doc.data().role === 'admin';
  } catch (e) {
    return false;
  }
}

/* ── إعادة تعيين كلمة المرور ── */
async function fbResetPassword(email) {
  if (!FIREBASE_ENABLED) return { success:false, error:'Firebase غير مفعّل' };
  try {
    await firebaseAuth.sendPasswordResetEmail(email);
    return { success:true };
  } catch (e) {
    return { success:false, error: e.message };
  }
}

/* ── الحصول على المستخدم الحالي ── */
function fbCurrentUser() {
  if (!FIREBASE_ENABLED) return null;
  return firebaseAuth.currentUser;
}
