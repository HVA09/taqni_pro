/* ═══════════════════════════════════════════════
   FIREBASE DATABASE — Firestore CRUD Operations
   ═══════════════════════════════════════════════
   هذا الملف يدير: المنتجات، المقالات، المفضلة،
   وتتبع النقرات — كل ذلك في Firestore بدلاً من
   الملفات الثابتة (js/app.js) إذا أردت قاعدة بيانات حية.
   ═══════════════════════════════════════════════ */

/* ════════════════════════════════════
   PRODUCTS — إدارة المنتجات
   ════════════════════════════════════ */

/* إضافة منتج جديد لقاعدة البيانات */
async function dbAddProduct(product) {
  if (!FIREBASE_ENABLED) return { success:false, error:'Firebase غير مفعّل' };
  try {
    await firebaseDB.collection('products').doc(product.id).set({
      ...product,
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      clicks: 0,
      views: 0,
    });
    return { success:true };
  } catch (e) { return { success:false, error:e.message }; }
}

/* تحديث منتج موجود */
async function dbUpdateProduct(id, updates) {
  if (!FIREBASE_ENABLED) return { success:false, error:'Firebase غير مفعّل' };
  try {
    await firebaseDB.collection('products').doc(id).update({
      ...updates,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
    });
    return { success:true };
  } catch (e) { return { success:false, error:e.message }; }
}

/* حذف منتج */
async function dbDeleteProduct(id) {
  if (!FIREBASE_ENABLED) return { success:false, error:'Firebase غير مفعّل' };
  try {
    await firebaseDB.collection('products').doc(id).delete();
    return { success:true };
  } catch (e) { return { success:false, error:e.message }; }
}

/* جلب كل المنتجات من قاعدة البيانات */
async function dbGetProducts() {
  if (!FIREBASE_ENABLED) return PRODUCTS; /* fallback للملف الثابت */
  try {
    const snap = await firebaseDB.collection('products').orderBy('createdAt','desc').get();
    return snap.docs.map(d => d.data());
  } catch (e) {
    console.warn('فشل جلب المنتجات من Firebase، استخدام البيانات المحلية', e);
    return PRODUCTS;
  }
}

/* جلب منتج واحد */
async function dbGetProduct(id) {
  if (!FIREBASE_ENABLED) return PRODUCTS.find(p => p.id === id);
  try {
    const doc = await firebaseDB.collection('products').doc(id).get();
    return doc.exists ? doc.data() : null;
  } catch (e) { return PRODUCTS.find(p => p.id === id); }
}

/* ════════════════════════════════════
   ARTICLES — إدارة المقالات
   ════════════════════════════════════ */

async function dbAddArticle(article) {
  if (!FIREBASE_ENABLED) return { success:false, error:'Firebase غير مفعّل' };
  try {
    await firebaseDB.collection('articles').doc(article.slug).set({
      ...article,
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      views: 0,
    });
    return { success:true };
  } catch (e) { return { success:false, error:e.message }; }
}

async function dbGetArticles() {
  if (!FIREBASE_ENABLED) return ARTICLES;
  try {
    const snap = await firebaseDB.collection('articles').orderBy('createdAt','desc').get();
    return snap.docs.map(d => d.data());
  } catch (e) { return ARTICLES; }
}

async function dbDeleteArticle(slug) {
  if (!FIREBASE_ENABLED) return { success:false };
  try {
    await firebaseDB.collection('articles').doc(slug).delete();
    return { success:true };
  } catch (e) { return { success:false, error:e.message }; }
}

/* ════════════════════════════════════
   WISHLIST SYNC — مزامنة المفضلة عبر الأجهزة
   ════════════════════════════════════ */

/* حفظ المفضلة في حساب المستخدم (بدل localStorage فقط) */
async function dbSyncWishlist(uid, wishlistArr) {
  if (!FIREBASE_ENABLED || !uid) return;
  try {
    await firebaseDB.collection('users').doc(uid).update({ wishlist: wishlistArr });
  } catch (e) { console.warn('فشل مزامنة المفضلة', e); }
}

/* جلب مفضلة المستخدم من حسابه */
async function dbGetWishlist(uid) {
  if (!FIREBASE_ENABLED || !uid) return [];
  try {
    const doc = await firebaseDB.collection('users').doc(uid).get();
    return doc.exists ? (doc.data().wishlist || []) : [];
  } catch (e) { return []; }
}

/* ════════════════════════════════════
   CLICK TRACKING — تتبع نقرات الشراء
   ════════════════════════════════════ */

/* تسجيل نقرة شراء على منتج (لتتبع الأداء الفعلي) */
async function dbTrackClick(productId) {
  if (!FIREBASE_ENABLED) {
    /* fallback: عدّاد محلي في localStorage */
    try {
      const clicks = JSON.parse(localStorage.getItem('tp_clicks') || '{}');
      clicks[productId] = (clicks[productId] || 0) + 1;
      localStorage.setItem('tp_clicks', JSON.stringify(clicks));
    } catch(e){}
    return;
  }
  try {
    await firebaseDB.collection('products').doc(productId).update({
      clicks: firebase.firestore.FieldValue.increment(1)
    });
    await firebaseDB.collection('clickLog').add({
      productId,
      timestamp: firebase.firestore.FieldValue.serverTimestamp(),
      userAgent: navigator.userAgent,
    });
  } catch (e) { console.warn('فشل تسجيل النقرة', e); }
}

/* تسجيل مشاهدة صفحة منتج */
async function dbTrackView(productId) {
  if (!FIREBASE_ENABLED) {
    try {
      const views = JSON.parse(localStorage.getItem('tp_views') || '{}');
      views[productId] = (views[productId] || 0) + 1;
      localStorage.setItem('tp_views', JSON.stringify(views));
    } catch(e){}
    return;
  }
  try {
    await firebaseDB.collection('products').doc(productId).update({
      views: firebase.firestore.FieldValue.increment(1)
    });
  } catch (e) { console.warn('فشل تسجيل المشاهدة', e); }
}

/* جلب إحصائيات النقرات لكل المنتجات (للوحة التحكم) */
async function dbGetClickStats() {
  if (!FIREBASE_ENABLED) {
    try { return JSON.parse(localStorage.getItem('tp_clicks') || '{}'); }
    catch(e){ return {}; }
  }
  try {
    const snap = await firebaseDB.collection('products').get();
    const stats = {};
    snap.docs.forEach(d => { stats[d.id] = d.data().clicks || 0; });
    return stats;
  } catch (e) { return {}; }
}
