/* ═══════════════════════════════════════════════
   FIREBASE CONFIG — تقني برو
   ═══════════════════════════════════════════════
   
   كيف تحصل على هذه البيانات:
   ① افتح console.firebase.google.com
   ② أنشئ مشروع جديد (Create a project)
   ③ سمّه "taqni-pro" أو أي اسم تريده
   ④ اذهب لـ Project Settings ⚙️ → General
   ⑤ انزل لـ "Your apps" → اضغط أيقونة Web </>
   ⑥ انسخ القيم وضعها أدناه
   
   ثم فعّل من القائمة الجانبية:
   - Authentication → Sign-in method → فعّل Email/Password
   - Firestore Database → Create database → ابدأ بوضع Test mode
   ═══════════════════════════════════════════════ */

const firebaseConfig = {
  apiKey:            "ضع_API_KEY_هنا",
  authDomain:         "your-project.firebaseapp.com",
  projectId:          "your-project-id",
  storageBucket:      "your-project.appspot.com",
  messagingSenderId:  "000000000000",
  appId:              "1:000000000000:web:xxxxxxxxxxxxx",
  measurementId:      "G-XXXXXXXXXX"   // اختياري - لـ Google Analytics
};

/* ═══════════════════════════════════════════════
   حالة الاتصال — يبقى false حتى تضيف بياناتك الحقيقية
   ═══════════════════════════════════════════════ */
const FIREBASE_ENABLED = firebaseConfig.apiKey !== "ضع_API_KEY_هنا";

/* تهيئة Firebase فقط إذا كانت البيانات حقيقية */
let firebaseApp = null;
let firebaseAuth = null;
let firebaseDB = null;

if (FIREBASE_ENABLED && typeof firebase !== 'undefined') {
  try {
    firebaseApp  = firebase.initializeApp(firebaseConfig);
    firebaseAuth = firebase.auth();
    firebaseDB   = firebase.firestore();
    console.log('✅ Firebase متصل بنجاح');
  } catch (e) {
    console.warn('⚠️ خطأ في الاتصال بـ Firebase:', e.message);
  }
} else {
  console.log('ℹ️ Firebase غير مفعّل — الموقع يعمل بنظام localStorage المحلي');
}
